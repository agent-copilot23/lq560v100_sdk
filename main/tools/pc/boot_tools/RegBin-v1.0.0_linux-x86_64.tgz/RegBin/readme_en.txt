Welcome to use the RegBin command line tool!

This tool is mainly used to generate a regbin file according to an Excel file. (Only Excel files in the 2007 version are supported. Other Excel files must be converted to the 2007 version first.)
The Linux operating systems are supported.

1. Function description of generating a regbin file

The steps are follows:

(1) In the command line, go to the directory where the RegBin is located.

(2) Enter the following command:./regbin [excelFile] <outputFile>
excelFile and outputFile are mandatory parameters and specified by the user.
Example:
./regbin ./******.xlsm ./reg.bin

If you want to write the version number, creation time, and table name into the table,
you need to add -magic magic number to be added (hexadecimal number, a maximum of 16 characters)
Example:
./regbin ./******.xlsm ./reg.bin -magic 3a4b5c6d
(3) Wait for the regbin file to be created successfully.
